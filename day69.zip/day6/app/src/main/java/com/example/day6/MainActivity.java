package com.example.day6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Movie x;new Movie(String "car", String "star", double "false", int "fivestar", String "past");
        Movie y;new Movie(String "bus", String "moon", double "true", int "fourstar", String "past");
    }
}